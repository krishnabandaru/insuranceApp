package com.globalClaim.insurance.dao.implementations;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import com.globalClaim.insurance.dao.interfaces.VehicleDao;
import com.globalClaim.insurance.helpers.OracleHelper;
import com.globalClaim.insurance.models.Vehicles;

public class VehicleImpl implements VehicleDao {

	private Connection conn;
	private CallableStatement callable;
	private ResourceBundle rb;
	private Statement statement;
	private ResultSet resultSet;
	{
		rb = ResourceBundle.getBundle("com/globalClaim/insurance/resources/db");
	}

	@Override
	public boolean addVehicle(Vehicles vehicle) throws SQLException {
		// TODO Auto-generated method stub
		boolean status = false;
		conn = OracleHelper.getConnection();
		CallableStatement callable;

		try {
			conn.setAutoCommit(false);
			callable = conn.prepareCall("{call addVehicle(?,?,?,?,?,?,?)}");
			callable.setString(1, vehicle.getRegistration());
			callable.setString(2, vehicle.getMaker());
			callable.setDate(3, Date.valueOf(vehicle.getDor()));
			callable.setString(4, vehicle.getChasisNo());
			callable.setString(5, vehicle.getEngineNo());
			callable.setString(6, vehicle.getFuelType());
			callable.setString(7, vehicle.getColor());
			int result = callable.executeUpdate();

			if (result != 0)
				status = true;
			conn.commit();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			conn.rollback();
			e.printStackTrace();
		} finally {
			conn.close();
		}
		return status;
	}

	@Override
	public List<Vehicles> getAllVehicles() throws SQLException {
		// TODO Auto-generated method stub

		List<Vehicles> vehicleList = new ArrayList<Vehicles>();

		conn = OracleHelper.getConnection();
		String query = rb.getString("query");
		try {
			statement = conn.createStatement();
			resultSet = statement.executeQuery(query);
			Vehicles vehicle = new Vehicles();
			while (resultSet.next()) {

				vehicle = new Vehicles();
				vehicle.setRegistration(resultSet.getString(1));
				vehicle.setMaker(resultSet.getString(2));
				vehicle.setDor(resultSet.getDate(3).toLocalDate());
				vehicle.setChasisNo(resultSet.getString(4));
				vehicle.setEngineNo(resultSet.getString(5));
				vehicle.setFuelType(resultSet.getString(6));
				vehicle.setColor(resultSet.getString(7));
				vehicleList.add(vehicle);

			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		} finally {

			conn.close();
		}
		return vehicleList;
	}

	@Override
	public Vehicles getVehicleById(String regNo) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean updateVehicle(Vehicles vehicle) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean deleteVehicle(String regNo) {
		// TODO Auto-generated method stub
		return false;
	}

}
