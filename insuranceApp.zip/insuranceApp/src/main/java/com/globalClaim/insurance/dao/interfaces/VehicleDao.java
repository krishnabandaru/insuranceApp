package com.globalClaim.insurance.dao.interfaces;

import java.sql.SQLException;
import java.util.List;

import com.globalClaim.insurance.models.Vehicles;

public interface VehicleDao {

	boolean addVehicle(Vehicles vehicle) throws SQLException;

	List<Vehicles> getAllVehicles() throws SQLException;

	Vehicles getVehicleById(String regNo);

	boolean updateVehicle(Vehicles vehicle);

	boolean deleteVehicle(String regNo);

}
