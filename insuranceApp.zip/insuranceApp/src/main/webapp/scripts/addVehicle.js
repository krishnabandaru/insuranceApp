/**
 * 
 */

window.addEventListener('load',function()
		{
	var ajaxObject=null;
	try{
		ajaxObject=new XMLHttpRequest();
	}
	catch(e){
		try{
			ajaxObject=new ActiveXObject("Msxml2.XMLHTTP3.0");
		}

		catch(e){
			alert("browser is broken or ajax ");
		}
	}




	document.querySelector("form").addEventListener("submit",function(){

		ajaxObject.open("post","../AddVechicle",true);
		var regNo=document.querySelector("#registrationNo").value;
		var maker=document.querySelector("#maker").value;
		var chasisNo=document.querySelector("#chasisNo").value;
		var engineNo=document.querySelector("#engineNo").value;
		var color=document.querySelector("#color").value;
		var dor=document.querySelector("#dor").value;
		var fuelType=document.querySelector("#fuelType").value;
		ajaxObject.setRequestHeader("Content-Type","application/x-www-form-urlencoded;");
		ajaxObject.send("regNo="+regNo+"&maker="+maker+"&chasisNo="+chasisNo+"&engineNo="+engineNo+"&color="+color+"&dor="+dor+"&fuelType="+fuelType);
		
		
		
		var formRef=document.querySelector("form");
		
		ajaxObject.onreadystatechange=function()
		{
			if((ajaxObject.readyState==4) && (ajaxObject.status=200))
				{
				console.log(ajaxObject.responseText);
				element=document.createElement("h2");
				textNode=document.createTextNode(ajaxObject.responseText);
				element.appendChild(textNode);
				formRef.appendChild(element);
				}
		}
		



	});
		});




